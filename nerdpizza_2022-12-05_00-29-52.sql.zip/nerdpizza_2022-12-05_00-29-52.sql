-- MariaDB dump 10.19  Distrib 10.6.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: nerdpizza
-- ------------------------------------------------------
-- Server version	10.6.11-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table ` bebidas`
--

DROP TABLE IF EXISTS ` bebidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE ` bebidas` (
  `idBebidas` int(255) NOT NULL AUTO_INCREMENT,
  `nombreBebida` varchar(255) NOT NULL,
  `precioBebida` double(65,2) NOT NULL,
  `contenidoB` varchar(255) NOT NULL,
  PRIMARY KEY (`idBebidas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table ` bebidas`
--

LOCK TABLES ` bebidas` WRITE;
/*!40000 ALTER TABLE ` bebidas` DISABLE KEYS */;
/*!40000 ALTER TABLE ` bebidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table ` tamaños`
--

DROP TABLE IF EXISTS ` tamaños`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE ` tamaños` (
  `idTamaño` int(255) NOT NULL AUTO_INCREMENT,
  `tamaño` varchar(255) NOT NULL,
  `precioT` double(65,2) NOT NULL,
  `nRebanadas` int(255) NOT NULL,
  PRIMARY KEY (`idTamaño`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table ` tamaños`
--

LOCK TABLES ` tamaños` WRITE;
/*!40000 ALTER TABLE ` tamaños` DISABLE KEYS */;
INSERT INTO ` tamaños` VALUES (1,'Chica',80.00,4),(2,'Mediana',152.00,8),(3,'Grande',216.00,12),(4,'Familiar',224.00,14),(5,'Jumbo',240.00,16);
/*!40000 ALTER TABLE ` tamaños` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `claves`
--

DROP TABLE IF EXISTS `claves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claves` (
  `id_clave` int(255) NOT NULL AUTO_INCREMENT,
  `correo_clave` varchar(255) NOT NULL,
  `clave_recuperación` bigint(255) NOT NULL,
  `emisión_clave` datetime DEFAULT NULL,
  `usada_clave` tinyint(1) DEFAULT NULL,
  `prueba_clave` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id_clave`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci COMMENT='Claves de recuperación de cuentas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claves`
--

LOCK TABLES `claves` WRITE;
/*!40000 ALTER TABLE `claves` DISABLE KEYS */;
INSERT INTO `claves` VALUES (1,'dantecc10@gmail.com',123456,'2022-11-30 00:00:00',0,0),(2,'dantecc10@gmail.com',136208,'2022-11-30 00:00:00',0,0),(3,'dantecc10@gmail.com',962487,'2022-11-30 00:00:00',0,0),(4,'dantecc10@gmail.com',510169,'2022-11-30 00:00:00',0,1),(5,'dantecc10@gmail.com',995277,'2022-11-30 00:00:00',0,1),(6,'dantecc10@gmail.com',432261,'2022-11-30 00:00:00',0,1),(7,'dante@castelancarpinteyro.club',457270,'2022-11-30 00:00:00',0,1),(8,'hola@errorcito.com',228595,'2022-11-30 00:00:00',0,1),(9,'',921185,'2022-11-30 00:00:00',0,1),(10,'jeremy.hdez9@gmail.com',964178,'2022-11-30 00:00:00',0,1),(11,'thedarcktorment123@gmail.com',760703,'2022-11-30 00:00:00',0,1),(12,'dante@castelancarpinteyro.club',434955,'2022-11-30 00:00:00',0,1),(13,'dante@castelancarpinteyro.club',492827,'2022-11-30 00:00:00',0,1),(14,'dante@castelancarpinteyro.club',103133,'2022-12-02 07:29:54',0,1),(15,'EMI@castelancarpinteyro.club',349503,'2022-12-02 07:30:08',0,1),(16,'EMI@castelancarpinteyro.club',864778,'2022-12-02 07:33:04',0,1),(17,'dante@classicandsacrum.com',894763,'2022-12-02 07:45:34',0,1),(18,'dante@castelancarpinteyro.club',584720,'2022-12-02 07:46:16',0,1),(19,'dantecc10@gmail.com',154353,'2022-12-02 07:57:56',0,1),(20,'jeremy@gmail.com',249401,'2022-12-02 07:58:10',0,1),(21,'jeremy@gmail.com',415637,'2022-12-02 07:59:10',0,1),(22,'jeremy@gmail.com',216437,'2022-12-02 07:59:13',0,1),(23,'jeremy@gmail.com',872830,'2022-12-02 07:59:19',0,1),(24,'soccer@mastersfc.com',556937,'2022-12-02 08:12:59',0,1),(25,'soccer@mastersfc.com',263391,'2022-12-02 08:14:03',0,1),(26,'soccer@mastersfc.com',978880,'2022-12-02 08:14:08',0,1),(27,'soccer@mastersfc.com',422630,'2022-12-02 08:15:22',0,1);
/*!40000 ALTER TABLE `claves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complementos`
--

DROP TABLE IF EXISTS `complementos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complementos` (
  `idComplemento` int(255) NOT NULL AUTO_INCREMENT,
  `nombreComplemento` varchar(255) NOT NULL,
  `precioComplemento` double(65,2) NOT NULL,
  `descripcionC` varchar(255) NOT NULL,
  `fotoComplemento` varchar(255) NOT NULL,
  PRIMARY KEY (`idComplemento`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complementos`
--

LOCK TABLES `complementos` WRITE;
/*!40000 ALTER TABLE `complementos` DISABLE KEYS */;
INSERT INTO `complementos` VALUES (1,'Alitas',70.00,'Alitas al carbón, preparadas con verdura y salsas de tu elección.','assets/img/pizzas/1/principal.png'),(2,'Papas fritas',53.00,'Papas fritas, preparadas con las salsas de tu gusto.','assets/img/pizzas/2/principal.png'),(3,'Nachos',50.00,'Nachos preparados con queso amarillo y acompañados de jalapeños o cualquier salsa de tu elección.','assets/img/pizzas/3/principal.png'),(4,'Nuggets de pollo',55.00,'Pollo empanizado y frito para prepararse con las salsas de tu gusto.','assets/img/pizzas/4/principal.png'),(5,'Breads',60.00,'Rollos de pan rellenos de queso.','assets/img/pizzas/5/principal.png'),(6,'Aros de cebolla',70.00,'Cebolla picada en rodajas, empanizada y frita, para prepararse con las salsas y aderezos de tu gusto.','assets/img/pizzas/6/principal.png');
/*!40000 ALTER TABLE `complementos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pizzas`
--

DROP TABLE IF EXISTS `pizzas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pizzas` (
  `idPizza` int(255) NOT NULL AUTO_INCREMENT,
  `nombrePizza` varchar(255) NOT NULL,
  `ingredientes` varchar(255) NOT NULL,
  `fotoPizza` varchar(255) NOT NULL,
  PRIMARY KEY (`idPizza`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pizzas`
--

LOCK TABLES `pizzas` WRITE;
/*!40000 ALTER TABLE `pizzas` DISABLE KEYS */;
INSERT INTO `pizzas` VALUES (1,'Hawaiiana','Queso mozzarella, rodajas de jamón, piña.','assets/img/pizzas/1/principal.png'),(2,'Margarita','Ajo, pan árabe, albahaca, queso parmesano, y jitomate.','assets/img/pizzas/2/principal.png'),(3,'Pepperoni','Jitomates, queso mozzarella, pepperoni, albahaca.','assets/img/pizzas/3/principal.png'),(4,'Mexicana','Reses, frijoles refritos, queso manchego, chorizo, aguacates, cebolla morada, cilantro, jalapeños.','assets/img/pizzas/4/principal.png'),(5,'Pita','Pan pita, queso manchego, salmón ahumado, arrachera asada, aceitunas, albahaca.','assets/img/pizzas/5/principal.png'),(6,'Portobello','Hongo portobello, especias, queso mozzarella, albahaca, jamón serrano, jitomate, tomillo.','assets/img/pizzas/6/principal.png');
/*!40000 ALTER TABLE `pizzas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `idUsuario` int(255) NOT NULL AUTO_INCREMENT,
  `nombreU` varchar(255) NOT NULL,
  `apellidosU` varchar(255) NOT NULL,
  `emailU` varchar(255) NOT NULL,
  `contraseñaU` varchar(255) NOT NULL,
  `direccionU` text NOT NULL,
  PRIMARY KEY (`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Dante','Castelán Carpinteyro','dantecc10@gmail.com','Nerd020305','3ra Privada de Josefa Ortiz de Domínguez'),(2,'Jhon','Connor','terminator@skynet.com','findelmundo','wachinto cd'),(4,'Roberto','Gomez Bolaños','elchavo@vecindad.com','semechispoteo1','la vecindad'),(5,'$nombre','$apellido','$email','$pass','$direccion'),(6,'Dante','Castelán Carpinteyro','dante@castelancarpinteyro.club','ContraseñaSegura22','En mi mansión');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-05  0:29:59
